# file name : run.py
# pwd : /project_name/run.py

from paramtuner.app import app

app.run(host="127.0.0.1", port=6006)

if __name__ == '__main__':
    pass