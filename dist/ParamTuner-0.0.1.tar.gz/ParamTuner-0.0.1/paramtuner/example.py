from paramtuner import VariableHolder

vh = VariableHolder(a=1, b=2, c=3)
from paramtuner.app.main.index import render_template
