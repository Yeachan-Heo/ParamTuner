from setuptools import setup

setup(
    name='ParamTuner',
    version='0.0.1',
    packages=['paramtuner', 'paramtuner.app', 'paramtuner.app.static', 'paramtuner.app.static.js',
              'paramtuner.app.static.css', 'paramtuner.app.static.fonts', 'paramtuner.app.templates',
              'paramtuner.app.templates.main'],
    url='',
    license='',
    author='ych',
    author_email='',
    description=''
)
