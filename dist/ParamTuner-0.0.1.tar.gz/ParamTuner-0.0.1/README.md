# ParamTuner. 
Parameter Tuner. 
1. paramtuner app/__init__.py를 import 하세요. 
2. example.py와 같이 Paramtuner를 초기화하세요(__init(**kwargs), paramtuner에 담을 변수의 초깃값을 설정하시면 됩니다)  
3. localhost:5000에 접속하시면 연결되 VariableHolder 클래스에 있는 변수들을 직접 튜닝하실 수 있겠습니다. 
4.learning rate, 강화학습의 discount factor, epsilon 등 많은 매뉴얼한 조정이 필요한 하이퍼파라미터들을 마음껏 조정하실 수 있습니다.  
